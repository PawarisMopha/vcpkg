void hello_mars();
